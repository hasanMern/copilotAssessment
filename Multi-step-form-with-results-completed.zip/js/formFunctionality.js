




$(document).ready(function () {

  $('.radio-buttons input[type="radio"]').on('change', function () {
    $('.box').removeClass('selected');
    $(this).siblings('.box').addClass('selected');
  });

  // Initialize the current form and step
  var currentForm = "Business-and-Vision-form";
  var step = 1;
  setActiveStep(1); // Set active class on the first step initially



  // Function to update the next button state based on radio button selection
  function updateNextButtonState() {
    var selectedSpan = $("#" + currentForm + " .step:eq(" + (step - 1) + ") .number span.selected");
    if (selectedSpan.length > 0) {
      $("#" + currentForm + " button.next").prop("disabled", false);
    } else {
      $("#" + currentForm + " button.next").prop("disabled", true);
    }
  }

  // Function to switch to the next form
  function switchToNextForm() {
    $("#" + currentForm).hide();
    step = 1;

    // Determine the next form to show and activate its corresponding nav-link
    if (currentForm === "Business-and-Vision-form") {
      currentForm = "Organizational-Mindset-and-Culture-form";
      $("#Organizational-Mindset-and-Culture").addClass("active");
    } else if (currentForm === "Organizational-Mindset-and-Culture-form") {
      currentForm = "Leadership-and-Governance-form";
      $("#Leadership-and-Governance").addClass("active");
    } else if (currentForm === "Leadership-and-Governance-form") {
      currentForm = "Data-and-Infrastructure-form";
      $("#Data-and-Infrastructure").addClass("active");
    } else if (currentForm === "Data-and-Infrastructure-form") {
      currentForm = "AI-Cognizance-form";
      $("#AI-Cognizance").addClass("active");
    } else if (currentForm === "AI-Cognizance-form") {
      currentForm = "Organizational-Workflows-form";
      $("#Organizational-Workflows").addClass("active");
    }

    // Show the next form, update progress and pagination for the new form
    $("#" + currentForm).show();

    // Scroll to the top of the newly shown form section
    $('.form-height').animate({
      scrollTop: $("#" + currentForm).offset().top
    }, 'slow');

    totalSteps = $("#" + currentForm + " .step").length;
    updateStepNumber(step);
    updateProgressBar(step, totalSteps);
    updateNextButtonState();
    $("#" + currentForm + " .step:last-child").removeClass("active");
    $("#" + currentForm + " .step:eq(" + (step - 1) + ")").addClass("active");

    setActiveStep(currentForm, 1);
    console.log(currentForm);
  }


  // Event listener for marking selected spans
  $("form .number span.box").click(function () {
    $("form .number span.box").removeClass("selected");
    $(this).addClass("selected");

    var lastStep = step === totalSteps; // Check if this is the last step

    $("#" + currentForm + " .step:not(:last-child):eq(" + (step - 1) + ")").hide(1000);
    $(".step").removeClass("active");
    // Increment step only if it's not the last step
    if (!lastStep) {
      step++;
      setActiveStep(step);
      updateStepNumber(step);
      updateProgressBar(step, totalSteps);
      updateNextButtonState();
    }

    if (!lastStep) {
      $("form .step:eq(" + (step - 1) + ")").show(1000);
    } else {
      // If all steps are completed in the current form, switch to the next form
      $("#" + currentForm + " .step:eq(" + (step - 1) + ")").addClass("active");
      $("#" + currentForm + " .step:last-child").css("display","block");
      $("button.next").prop("disabled", false);
    }
  });



  // Function to set the active step
  function setActiveStep(step) {
    $("#" + currentForm + " .step:eq(" + (step - 1) + ")").addClass("active");
  }





  // Function to update the step number in the pagination display with fade-in effect
  function updateStepNumber(stepNumber) {
    var $pagination = $("#pagination");
    // var updatedText = stepNumber + "/" + totalSteps; // Dynamic pagination text

    // Create a temporary span element to contain the stepNumber and apply a fade-in effect to it
    var $stepSpan = $("<span>").text(stepNumber).hide();

    // Update the pagination content to contain the static part and append the stepNumber span
    $pagination.find(".pagination-steps").empty().append($stepSpan, "/" + totalSteps);

    // Apply the fade-in effect to the stepNumber span
    $stepSpan.fadeIn(300);
  }

  function updateProgressBar(step, totalSteps) {
    var percent = (step / totalSteps) * 100;
    $("#progress-bar").css("width", percent + "%");
    $("#percentage-text").text(Math.round(percent) + "%");
  }

  // Initial setup: Hide all forms except the first one
  $(".form-wrapper form").hide();
  $("#" + currentForm).show();
  var totalSteps = $("#" + currentForm + " .step").length;
  updateStepNumber(step);
  updateProgressBar(step, totalSteps);
  updateNextButtonState();



  // Next button click handler
  $("button.next").on("click", function () {
    var lastStep = step === totalSteps;
    if (!lastStep) {
      $("#" + currentForm + " .step:eq(" + (step - 1) + ")").show(1000);
    } else {
      // If all steps are completed in the current form, switch to the next form
      switchToNextForm();
      setActiveStep(currentForm, 1); // Set active class on the first step of the new form
    }
  });

});

